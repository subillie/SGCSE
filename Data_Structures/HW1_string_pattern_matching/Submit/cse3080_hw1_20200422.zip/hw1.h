#ifndef HW1_H
#define HW1_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_STRING_SIZE 10000000
#define MAX_PATTERN_SIZE 3000

int failure[MAX_PATTERN_SIZE];
char string[MAX_STRING_SIZE];
char pattern[MAX_PATTERN_SIZE];

#endif
